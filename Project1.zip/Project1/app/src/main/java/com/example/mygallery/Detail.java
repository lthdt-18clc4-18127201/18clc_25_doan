package com.example.mygallery;

public class Detail {
}
